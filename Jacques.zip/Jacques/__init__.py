from __future__ import absolute_import
from .Jacques import Jacques


def create_instance(*a):
    return Jacques(*a)
