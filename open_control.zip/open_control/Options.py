# CHANGE THE WIDTH OF THE SESSION BOX
# MAXIMUM = 4
number_of_tracks = 4
session_box_linked_to_selection = 1
fixed_length_recording = 0
metronome_blinking = 0
page_1_color = 13
page_2_color = 52
page_3_color = 21

display_time = 0.1