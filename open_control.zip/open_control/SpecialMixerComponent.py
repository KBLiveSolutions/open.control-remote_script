from __future__ import absolute_import
from _Framework.SubjectSlot import subject_slot
from . import Options

from _Framework.MixerComponent import MixerComponent as MixerBase

from .SpecialChannelStripComponent import ChannelStripComponent


class MixerComponent(MixerBase):
    """ MixerComponent extends the standard to use a custom SceneComponent, use custom
    ring handling and observe the status of scenes. """

    channel_strip_component_type = ChannelStripComponent

    def __init__(self, *a, **k):
        super(MixerComponent, self).__init__(*a, **k)
        self._rgb_controls = None
        self._name_controls = None
        self.last_message_time = 0
    
    def set_parent(self, parent):
        self.parent = parent

    def disconnect(self):
        super(MixerComponent, self).disconnect()

    def _create_strip(self):
        return ChannelStripComponent()

    def update(self):
        super(MixerComponent, self).update()

    def on_track_list_changed(self):
        # self._setup_track_listeners()
        super(MixerComponent, self).on_track_list_changed()
    
    def set_master_volume(self, button):
        self.master_volume_button = button
        self.master_strip().set_volume_control(button)
        self._master_volume_value.subject = button

    def set_volume(self, button):
        self.selected_strip().set_volume_control(button)
        self._volume_value.subject = button

    def set_pan(self, button):
        self.selected_strip().set_pan_control(button)
        self._pan_value.subject = button

    @subject_slot('value')
    def _master_volume_value(self, value):
        volume = self.song().master_track.mixer_device.volume
        self.parent.set_temp_message(str(volume))

    def set_send_controls(self, buttons):
        self.selected_strip().set_send_controls(buttons)
        self._send_controls_value.subject = buttons

    @subject_slot('value')
    def _send_controls_value(self, *args):
        sends = self._selected_strip._track.mixer_device.sends[args[1]]
        self.parent.set_temp_message(str(sends))

    @subject_slot('value')
    def _volume_value(self, value):
        volume = self._selected_strip._track.mixer_device.volume
        self.parent.set_temp_message(str(volume))

    @subject_slot('value')
    def _pan_value(self, value):
        panning = self._selected_strip._track.mixer_device.panning
        self.parent.set_temp_message(str(panning))